import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

/** Single-row table: giveaway settings (jsonb) + admin password. */
export const settings = pgTable("gx_settings", {
  id: integer("id").primaryKey(),
  data: jsonb("data").$type<Record<string, unknown>>().notNull(),
  adminPassword: text("admin_password").notNull(),
});

/** A "pass" is created when a visitor presses the big button. It lets them into /claim once. */
export const passes = pgTable("gx_passes", {
  id: text("id").primaryKey(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  clicks: integer("clicks").default(1).notNull(),
  used: boolean("used").default(false).notNull(),
  ip: text("ip"),
});

export const entries = pgTable(
  "gx_entries",
  {
    id: serial("id").primaryKey(),
    number: integer("number").notNull(),
    username: text("username").notNull(),
    email: text("email"),
    platform: text("platform").default("tiktok").notNull(),
    passId: text("pass_id"),
    status: text("status").default("pending").notNull(),
    won: boolean("won").default(false).notNull(),
    prize: text("prize").default("").notNull(),
    ip: text("ip"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => [index("gx_entries_status_idx").on(t.status), index("gx_entries_ip_idx").on(t.ip)],
);

export const draws = pgTable("gx_draws", {
  id: serial("id").primaryKey(),
  batch: text("batch").notNull(),
  place: integer("place").notNull(),
  entryId: integer("entry_id").notNull(),
  username: text("username").notNull(),
  email: text("email"),
  prize: text("prize").notNull(),
  poolSize: integer("pool_size").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
