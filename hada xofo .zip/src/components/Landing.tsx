"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import type { PublicData } from "@/lib/types";

const FIRST = ["Blox", "Noob", "Pro", "Epic", "Ninja", "Dark", "Mega", "Lucky", "Shadow", "Tiger", "Cool", "Fire", "Sky", "Turbo", "Pixel"];
const LAST = ["Gamer", "Player", "King", "Master", "YT", "Boy", "RBX", "Hero", "Wolf", "Queen", "Builder", "Legend"];

function fakeName() {
  const a = FIRST[Math.floor(Math.random() * FIRST.length)];
  const b = LAST[Math.floor(Math.random() * LAST.length)];
  const n = Math.random() < 0.6 ? String(Math.floor(Math.random() * 99)) : "";
  const full = a + b + n;
  return full.slice(0, 2) + "***" + full.slice(-1);
}

function useCountdown(deadline: string) {
  const target = useMemo(() => (deadline ? new Date(deadline).getTime() : 0), [deadline]);
  const [left, setLeft] = useState<number | null>(null);
  useEffect(() => {
    const tick = () => setLeft(Math.max(0, target - Date.now()));
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, [target]);
  return left;
}

function Coins() {
  const coins = Array.from({ length: 14 }, (_, i) => ({
    x: `${(i * 37 + 5) % 96}%`,
    s: `${26 + ((i * 13) % 26)}px`,
    d: `${7 + ((i * 5) % 7)}s`,
    delay: `${-((i * 1.7) % 9)}s`,
  }));
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      {coins.map((c, i) => (
        <span
          key={i}
          className="coin"
          style={{ "--x": c.x, "--s": c.s, "--d": c.d, "--delay": c.delay } as React.CSSProperties}
        >
          R$
        </span>
      ))}
    </div>
  );
}

function Countdown({ left }: { left: number | null }) {
  if (left === null) return <div className="h-[84px]" />;
  if (left === 0) {
    return (
      <div className="glass inline-block px-6 py-4 text-lg font-extrabold text-amber-300">
        ⏳ Entries closing — winners are being picked!
      </div>
    );
  }
  const s = Math.floor(left / 1000);
  const parts = [
    ["Days", Math.floor(s / 86400)],
    ["Hours", Math.floor((s % 86400) / 3600)],
    ["Min", Math.floor((s % 3600) / 60)],
    ["Sec", s % 60],
  ] as const;
  return (
    <div className="flex items-center justify-center gap-2 sm:gap-3">
      {parts.map(([label, v]) => (
        <div key={label} className="glass min-w-[68px] px-3 py-2 text-center sm:min-w-[84px]">
          <div className="text-3xl font-black tabular-nums sm:text-4xl">{String(v).padStart(2, "0")}</div>
          <div className="text-[11px] font-bold uppercase tracking-widest text-white/60">{label}</div>
        </div>
      ))}
    </div>
  );
}

export default function Landing({ initial }: { initial: PublicData }) {
  const [data, setData] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState<{ id: number; name: string; text: string } | null>(null);
  const s = data.settings;
  const left = useCountdown(s.deadline);

  // refresh the live counter
  useEffect(() => {
    const t = setInterval(() => {
      fetch("/api/public")
        .then((r) => r.json())
        .then((d: PublicData) => setData(d))
        .catch(() => {});
    }, 30000);
    return () => clearInterval(t);
  }, []);

  // unlock the button again if the visitor comes back with the Back button
  useEffect(() => {
    const onShow = () => setBusy(false);
    window.addEventListener("pageshow", onShow);
    return () => window.removeEventListener("pageshow", onShow);
  }, []);

  // activity notifications
  useEffect(() => {
    if (!s.notifyEnabled) return;
    let id = 0;
    const show = () => {
      const real = data.recent;
      const useReal = real.length > 0 && Math.random() < 0.4;
      const name = useReal ? real[Math.floor(Math.random() * real.length)] : fakeName();
      const prize = s.prizes[Math.floor(Math.random() * s.prizes.length)] ?? "Robux";
      setToast({ id: ++id, name, text: `just entered the giveaway for ${prize}` });
    };
    const first = setTimeout(show, 1200);
    const t = setInterval(show, Math.max(1, s.notifySeconds) * 1000);
    return () => {
      clearTimeout(first);
      clearInterval(t);
    };
  }, [s.notifyEnabled, s.notifySeconds, s.prizes, data.recent]);

  const go = useCallback(async () => {
    if (busy) return;
    setBusy(true);
    try {
      const r = await fetch("/api/click", { method: "POST" });
      const d = await r.json();
      if (!r.ok || !d.lockerUrl) throw new Error("fail");
      // same tab redirect (required by content lockers)
      window.location.href = d.lockerUrl;
      setTimeout(() => setBusy(false), 6000);
    } catch {
      alert("Connection problem. Please try again.");
      setBusy(false);
    }
  }, [busy]);

  const cta = (label = "Click here to enter now") => (
    <button className="cta" onClick={go} disabled={busy}>
      {busy ? "Opening…" : label}
      {!busy && <span className="arrow">➜</span>}
    </button>
  );

  const medals = ["🥇", "🥈", "🥉"];
  const podium = s.prizes.slice(0, 3);
  // visual order: 2nd, 1st, 3rd
  const order = podium.length === 3 ? [1, 0, 2] : podium.map((_, i) => i);

  return (
    <div className="relative overflow-x-hidden">
      <Coins />

      {/* top bar */}
      <header className="relative z-10 mx-auto flex max-w-5xl items-center justify-between px-4 py-4">
        <div className="flex items-center gap-2 text-lg font-black tracking-wide">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-amber-300 to-orange-500 text-sm text-amber-950 shadow-lg">
            R$
          </span>
          {s.brandName}
        </div>
        <div className="glass flex items-center gap-2 px-3 py-1.5 text-sm font-bold">
          <span className="relative flex h-2.5 w-2.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-green-400 opacity-75" />
            <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-green-400" />
          </span>
          {(s.baseCount + data.total).toLocaleString("en-US")} entered
        </div>
      </header>

      {/* hero */}
      <section className="relative z-10 mx-auto max-w-5xl px-4 pb-10 pt-6 text-center">
        <div className="mx-auto mb-4 inline-flex items-center gap-2 rounded-full bg-red-500/90 px-4 py-1 text-xs font-black uppercase tracking-widest">
          <span className="h-2 w-2 animate-pulse rounded-full bg-white" /> Live giveaway
        </div>
        <h1 className="gradient-text mx-auto max-w-3xl text-5xl font-black leading-[1.02] sm:text-7xl">{s.headline}</h1>
        <p className="mx-auto mt-4 max-w-xl text-lg font-medium text-white/80 sm:text-xl">{s.subheadline}</p>

        <div className="mt-7">
          <div className="mb-2 text-xs font-bold uppercase tracking-[0.25em] text-white/60">Giveaway ends in</div>
          <Countdown left={left} />
        </div>

        {/* prizes */}
        <div className="mx-auto mt-10 grid max-w-3xl grid-cols-3 items-end gap-2 sm:gap-5">
          {order.map((i) => (
            <div
              key={i}
              className={`prize-card glass flex flex-col items-center px-2 py-5 sm:px-4 ${
                i === 0 ? "border-amber-300/60 pb-9 pt-8 shadow-[0_0_50px_rgba(255,200,61,0.35)]" : ""
              }`}
            >
              <div className={i === 0 ? "text-5xl sm:text-6xl" : "text-4xl sm:text-5xl"}>{medals[i]}</div>
              <div className="mt-1 text-[11px] font-black uppercase tracking-widest text-white/60">
                {i === 0 ? "1st place" : i === 1 ? "2nd place" : "3rd place"}
              </div>
              <div className={`mt-1 font-black text-amber-300 ${i === 0 ? "text-2xl sm:text-4xl" : "text-lg sm:text-2xl"}`}>
                {podium[i]}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-10 flex flex-col items-center gap-3">
          {cta()}
          <p className="text-sm text-white/60">🔒 Takes about 5–15 minutes · Pick your winners below ↓</p>
        </div>
      </section>

      {/* steps */}
      <section className="relative z-10 mx-auto max-w-5xl px-4 py-10">
        <h2 className="mb-8 text-center text-3xl font-black uppercase sm:text-5xl">How to enter — 3 steps</h2>
        <div className="grid gap-4 md:grid-cols-3">
          {[
            ["1", "Read the 2 offers", "Scroll down and read how to complete each offer."],
            ["2", "Press the big green button", "Complete BOTH offers on the page that opens."],
            ["3", "Write your Roblox username", "You are sent back here to write your username. Done!"],
          ].map(([n, t, d]) => (
            <div key={n} className="glass flex items-center gap-4 p-6 md:flex-col md:text-center">
              <div className="step-num text-7xl md:text-8xl">{n}</div>
              <div>
                <div className="text-xl font-extrabold sm:text-2xl">{t}</div>
                <div className="mt-1 text-base text-white/70 sm:text-lg">{d}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* offers */}
      <section className="relative z-10 mx-auto max-w-5xl px-4 py-10">
        <h2 className="mb-2 text-center text-3xl font-black uppercase sm:text-5xl">The {s.offers.length} offers</h2>
        <p className="mb-8 text-center text-lg text-white/70">Complete both to get your entry.</p>
        <div className="grid gap-5 md:grid-cols-2">
          {s.offers.map((o, idx) => (
            <div key={idx} className="glass p-6 sm:p-7">
              <div className="mb-4 flex flex-wrap items-center gap-2">
                <span className="rounded-lg bg-green-400 px-3 py-1 text-sm font-black text-green-950">OFFER {idx + 1}</span>
                {o.badge && <span className="rounded-lg bg-white/10 px-3 py-1 text-sm font-bold">{o.badge}</span>}
                {o.time && <span className="rounded-lg bg-white/10 px-3 py-1 text-sm font-bold">⏱ {o.time}</span>}
              </div>
              <h3 className="text-3xl font-black sm:text-4xl">{o.name}</h3>
              <p className="mt-1 text-sm font-bold uppercase tracking-widest text-white/50">How to complete this offer</p>
              <ol className="mt-4 space-y-3">
                {o.steps.map((st, i) => (
                  <li key={i} className="flex gap-3 text-lg leading-snug sm:text-xl">
                    <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-full bg-amber-300 text-base font-black text-amber-950">
                      {i + 1}
                    </span>
                    <span>{st}</span>
                  </li>
                ))}
              </ol>
            </div>
          ))}
        </div>
      </section>

      {/* second CTA */}
      <section className="relative z-10 mx-auto max-w-3xl px-4 py-12 text-center">
        <div className="text-2xl font-black sm:text-4xl">Ready? Let&apos;s go! 🚀</div>
        <div className="mt-6 flex justify-center">
          {cta("Start the offers")}
        </div>
      </section>

      {/* winners */}
      {data.winners.length > 0 && (
        <section className="relative z-10 mx-auto max-w-3xl px-4 py-6">
          <h2 className="mb-4 text-center text-2xl font-black uppercase">🏆 Latest winners</h2>
          <div className="grid gap-3">
            {data.winners.map((w, i) => (
              <div key={i} className="glass flex items-center justify-between px-5 py-3 text-lg font-bold">
                <span>
                  {medals[i] ?? "🏅"} {w.username}
                </span>
                <span className="text-amber-300">{w.prize}</span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* FAQ */}
      <section className="relative z-10 mx-auto max-w-3xl px-4 py-10">
        <h2 className="mb-6 text-center text-3xl font-black uppercase">FAQ</h2>
        <div className="space-y-3">
          {[
            ["How many winners are there?", `${s.prizes.length} winners are picked at random from all valid entries.`],
            ["When are the winners picked?", "When the countdown ends. Winners are announced on our TikTok and YouTube."],
            ["How do I get my Robux?", "Winners are contacted using the Roblox username they entered."],
            ["Can I enter more than once?", "No. One Roblox username = one entry. Duplicates are removed."],
          ].map(([q, a]) => (
            <details key={q} className="glass group px-5 py-4">
              <summary className="cursor-pointer list-none text-lg font-extrabold">
                <span className="mr-2 inline-block text-green-400 transition group-open:rotate-90">▶</span>
                {q}
              </summary>
              <p className="mt-2 pl-6 text-white/75">{a}</p>
            </details>
          ))}
        </div>
      </section>

      <footer className="relative z-10 mx-auto max-w-3xl px-4 pb-28 pt-6 text-center text-xs leading-relaxed text-white/45">
        <p>
          This giveaway is not sponsored, endorsed or administered by Roblox Corporation. Roblox and Robux are trademarks of
          Roblox Corporation. Offers are provided by third parties and may have age or device requirements — make sure you
          qualify (and have a parent&apos;s permission if you are under 18) before you start.
        </p>
        <p className="mt-2">© {new Date().getFullYear()} {s.brandName}</p>
      </footer>

      {/* notifications */}
      {s.notifyEnabled && toast && (
        <div className="pointer-events-none fixed bottom-4 left-4 right-4 z-50 sm:right-auto">
          <div key={toast.id} className="toast glass flex max-w-sm items-center gap-3 bg-[#14122e]/90 px-4 py-3 shadow-2xl">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-gradient-to-br from-amber-300 to-orange-500 font-black text-amber-950">
              R$
            </span>
            <div className="text-sm leading-tight">
              <b className="text-base">{toast.name}</b>
              <div className="text-white/75">{toast.text}</div>
              <div className="text-xs text-green-400">● just now</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
