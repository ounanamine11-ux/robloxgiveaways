"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import type { Settings } from "@/lib/types";

type Entry = {
  id: number;
  number: number;
  username: string;
  email: string | null;
  platform: string;
  status: "pending" | "verified" | "rejected";
  won: boolean;
  prize: string;
  ip: string | null;
  createdAt: number;
};
type Draw = { id: number; batch: string; place: number; entryId: number; username: string; email: string | null; prize: string; poolSize: number; createdAt: number };
type Overview = {
  settings: Settings;
  stats: Record<"total" | "verified" | "pending" | "rejected" | "today" | "winners" | "passes" | "clicks", number>;
  entries: Entry[];
  draws: Draw[];
};

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const toLocalInput = (iso: string) => {
  if (!iso) return "";
  const d = new Date(iso);
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
};

async function post(body: Record<string, unknown>) {
  const r = await fetch("/api/admin", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const d = await r.json().catch(() => ({}));
  if (r.status === 401) throw new Error("auth");
  return d;
}

const inputCls = "w-full rounded-lg border border-white/15 bg-black/30 px-3 py-2 outline-none focus:border-green-400";
const btnCls = "rounded-lg bg-white/10 px-3 py-2 text-sm font-bold hover:bg-white/20";

export default function AdminPanel() {
  const [authed, setAuthed] = useState<boolean | null>(null);
  const [data, setData] = useState<Overview | null>(null);
  const [tab, setTab] = useState<"entries" | "draw" | "settings" | "links">("entries");
  const [pw, setPw] = useState("");
  const [loginErr, setLoginErr] = useState("");

  const load = useCallback(async () => {
    const r = await fetch("/api/admin");
    if (r.status === 401) {
      setAuthed(false);
      return;
    }
    setData(await r.json());
    setAuthed(true);
  }, []);

  useEffect(() => {
    load().catch(() => setAuthed(false));
  }, [load]);

  async function login(e: React.FormEvent) {
    e.preventDefault();
    setLoginErr("");
    const r = await fetch("/api/admin/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ password: pw }) });
    if (r.ok) {
      setPw("");
      await load();
    } else setLoginErr(r.status === 429 ? "Too many attempts. Wait a minute." : "Wrong password.");
  }

  async function logout() {
    await fetch("/api/admin/login", { method: "DELETE" });
    setAuthed(false);
    setData(null);
  }

  if (authed === null) return <div className="p-10 text-center text-white/60">Loading…</div>;

  if (!authed || !data) {
    return (
      <main className="mx-auto flex min-h-screen max-w-sm items-center px-4">
        <form onSubmit={login} className="glass w-full space-y-4 p-7">
          <div className="text-center text-4xl">🔐</div>
          <h1 className="text-center text-2xl font-black">Admin login</h1>
          <input type="password" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="Password" className={inputCls} autoFocus />
          {loginErr && <div className="rounded-lg bg-red-500/20 px-3 py-2 text-sm font-bold text-red-200">{loginErr}</div>}
          <button className="w-full rounded-lg bg-green-400 py-3 font-black text-green-950 hover:bg-green-300">Enter</button>
          <p className="text-center text-xs text-white/50">
            Default password: <b>robux2026</b> — change it in Settings after your first login.
          </p>
        </form>
      </main>
    );
  }

  const s = data.stats;
  return (
    <main className="mx-auto max-w-6xl px-4 py-6">
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-black">🎛 {data.settings.brandName} — Admin</h1>
        <div className="flex gap-2">
          <a href="/" target="_blank" className={btnCls}>
            View site ↗
          </a>
          <button onClick={logout} className={btnCls}>
            Logout
          </button>
        </div>
      </div>

      <div className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-8">
        {(
          [
            ["Entries", s.total],
            ["Today", s.today],
            ["Verified", s.verified],
            ["Pending", s.pending],
            ["Rejected", s.rejected],
            ["Winners", s.winners],
            ["Button clicks", s.clicks],
            ["Passes", s.passes],
          ] as const
        ).map(([l, v]) => (
          <div key={l} className="glass px-3 py-3 text-center !rounded-xl">
            <div className="text-2xl font-black">{v}</div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-white/55">{l}</div>
          </div>
        ))}
      </div>

      <div className="mb-5 flex gap-2 overflow-x-auto">
        {(
          [
            ["entries", "📋 Entries"],
            ["draw", "🎲 Draw winners"],
            ["settings", "⚙️ Settings"],
            ["links", "🔗 Links"],
          ] as const
        ).map(([k, l]) => (
          <button
            key={k}
            onClick={() => setTab(k)}
            className={`whitespace-nowrap rounded-xl px-4 py-2 font-bold ${tab === k ? "bg-green-400 text-green-950" : "bg-white/10 hover:bg-white/20"}`}
          >
            {l}
          </button>
        ))}
      </div>

      {tab === "entries" && <EntriesTab data={data} reload={load} />}
      {tab === "draw" && <DrawTab data={data} reload={load} />}
      {tab === "settings" && <SettingsTab data={data} reload={load} />}
      {tab === "links" && <LinksTab data={data} />}
    </main>
  );
}

/* ------------------------------ ENTRIES ------------------------------ */
function EntriesTab({ data, reload }: { data: Overview; reload: () => Promise<void> }) {
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState("all");

  const rows = useMemo(
    () =>
      data.entries.filter(
        (e) =>
          (filter === "all" || (filter === "won" ? e.won : e.status === filter)) &&
          (!q || (e.username + " " + (e.email ?? "")).toLowerCase().includes(q.toLowerCase())),
      ),
    [data.entries, q, filter],
  );

  async function act(body: Record<string, unknown>) {
    await post(body);
    await reload();
  }

  function csv() {
    const esc = (v: unknown) => '"' + String(v ?? "").replace(/"/g, '""') + '"';
    const head = ["#", "Roblox username", "Email", "Platform", "Status", "Winner", "Prize", "Date"];
    const lines = data.entries
      .slice()
      .reverse()
      .map((e) => [e.number, e.username, e.email, e.platform, e.status, e.won ? "YES" : "", e.prize, new Date(e.createdAt).toISOString()]);
    const text = "\uFEFF" + [head, ...lines].map((r) => r.map(esc).join(",")).join("\r\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([text], { type: "text/csv;charset=utf-8" }));
    a.download = `entries-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
  }

  return (
    <div className="glass p-4">
      <div className="mb-4 flex flex-wrap gap-2">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search username / email…" className={inputCls + " max-w-xs"} />
        <select value={filter} onChange={(e) => setFilter(e.target.value)} className={inputCls + " max-w-[150px]"}>
          {["all", "pending", "verified", "rejected", "won"].map((f) => (
            <option key={f} value={f} className="text-black">
              {f}
            </option>
          ))}
        </select>
        <button onClick={csv} className={btnCls}>
          ⬇ Export CSV
        </button>
        <button onClick={() => reload()} className={btnCls}>
          ↻ Refresh
        </button>
        <button
          onClick={() => confirm("Delete all rejected entries?") && act({ action: "clear", what: "rejected" })}
          className={btnCls}
        >
          🗑 Clear rejected
        </button>
        <button
          onClick={() => confirm("DELETE EVERYTHING (entries, draws, passes)? This cannot be undone.") && act({ action: "clear", what: "all" })}
          className="rounded-lg bg-red-500/30 px-3 py-2 text-sm font-bold hover:bg-red-500/50"
        >
          ⚠ Reset all
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead className="text-xs uppercase tracking-wider text-white/50">
            <tr>
              <th className="p-2">#</th>
              <th className="p-2">Roblox username</th>
              <th className="p-2">Email</th>
              <th className="p-2">From</th>
              <th className="p-2">Status</th>
              <th className="p-2">Date</th>
              <th className="p-2 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((e) => (
              <tr key={e.id} className="border-t border-white/10">
                <td className="p-2 text-white/50">{e.number}</td>
                <td className="p-2 font-extrabold">
                  {e.won && "🏆 "}
                  {e.username}
                  {e.won && <span className="ml-2 text-xs text-amber-300">{e.prize}</span>}
                </td>
                <td className="p-2 text-white/70">{e.email ?? "—"}</td>
                <td className="p-2 capitalize">{e.platform}</td>
                <td className="p-2">
                  <span
                    className={`rounded-md px-2 py-0.5 text-xs font-bold ${
                      e.status === "verified" ? "bg-green-400/25 text-green-300" : e.status === "rejected" ? "bg-red-400/25 text-red-300" : "bg-amber-400/25 text-amber-300"
                    }`}
                  >
                    {e.status}
                  </span>
                </td>
                <td className="p-2 text-white/60">{new Date(e.createdAt).toLocaleString()}</td>
                <td className="p-2 text-right">
                  <div className="inline-flex gap-1">
                    <button title="Verify" onClick={() => act({ action: "status", id: e.id, status: "verified" })} className={btnCls}>
                      ✓
                    </button>
                    <button title="Pending" onClick={() => act({ action: "status", id: e.id, status: "pending" })} className={btnCls}>
                      ⏳
                    </button>
                    <button title="Reject" onClick={() => act({ action: "status", id: e.id, status: "rejected" })} className={btnCls}>
                      ✗
                    </button>
                    <button title="Delete" onClick={() => confirm(`Delete ${e.username}?`) && act({ action: "delete", id: e.id })} className={btnCls}>
                      🗑
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {!rows.length && (
              <tr>
                <td colSpan={7} className="p-8 text-center text-white/50">
                  No entries yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ------------------------------ DRAW ------------------------------ */
function DrawTab({ data, reload }: { data: Overview; reload: () => Promise<void> }) {
  const [count, setCount] = useState(data.settings.winnersCount);
  const [onlyVerified, setOnlyVerified] = useState(false);
  const [excl, setExcl] = useState(true);
  const [running, setRunning] = useState(false);
  const [rolling, setRolling] = useState("");
  const [shown, setShown] = useState<Draw[]>([]);
  const [msg, setMsg] = useState("");

  async function run() {
    setMsg("");
    setShown([]);
    setRunning(true);
    try {
      const d = await post({ action: "draw", count, onlyVerified, excludeWinners: excl });
      if (d.error === "empty") {
        setMsg("No eligible entries to draw from.");
        return;
      }
      const reel: string[] = d.reel?.length ? d.reel : ["…"];
      const winners: Draw[] = d.winners;
      for (const w of winners) {
        for (let i = 0; i < 32; i++) {
          setRolling(reel[Math.floor(Math.random() * reel.length)]);
          await sleep(60 + i * 6);
        }
        setRolling(w.username);
        await sleep(350);
        setShown((p) => [...p, w]);
        await sleep(450);
      }
      setRolling("");
      await reload();
    } catch {
      setMsg("Error while drawing.");
    } finally {
      setRunning(false);
    }
  }

  const place = (n: number) => (n === 1 ? "🥇" : n === 2 ? "🥈" : n === 3 ? "🥉" : "🏅");

  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <div className="glass p-6 text-center">
        <h2 className="mb-4 text-xl font-black">Pick the winners</h2>
        <div className="mb-5 flex flex-wrap items-center justify-center gap-4 text-sm">
          <label className="flex items-center gap-2">
            Winners
            <input type="number" min={1} max={10} value={count} onChange={(e) => setCount(Number(e.target.value))} className={inputCls + " !w-20"} />
          </label>
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={onlyVerified} onChange={(e) => setOnlyVerified(e.target.checked)} className="h-4 w-4 accent-green-400" /> Verified only
          </label>
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={excl} onChange={(e) => setExcl(e.target.checked)} className="h-4 w-4 accent-green-400" /> Skip previous winners
          </label>
        </div>

        <div className="mb-5 grid min-h-[110px] place-items-center rounded-2xl border-2 border-dashed border-amber-300/40 bg-black/30 p-4">
          {running && rolling ? (
            <div className="text-3xl font-black text-amber-300 sm:text-4xl">{rolling}</div>
          ) : (
            <div className="text-white/40">{running ? "…" : "Press the button to draw"}</div>
          )}
        </div>

        <button onClick={run} disabled={running} className="cta" style={{ maxWidth: 420, fontSize: "1.4rem", padding: "1.1rem 1.5rem" }}>
          {running ? "Drawing…" : `🎲 Draw ${count} winners`}
        </button>
        {msg && <div className="mt-3 font-bold text-red-300">{msg}</div>}

        <div className="mt-6 space-y-3 text-left">
          {shown.map((w) => (
            <div key={w.id} className="win-pop flex items-center justify-between rounded-xl border border-amber-300/50 bg-amber-300/10 px-4 py-3">
              <span className="text-xl font-black">
                {place(w.place)} {w.username}
              </span>
              <span className="font-bold text-amber-300">{w.prize}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="glass p-6">
        <h2 className="mb-4 text-xl font-black">Draw history</h2>
        <div className="max-h-[520px] space-y-2 overflow-y-auto">
          {data.draws.map((d) => (
            <div key={d.id} className="flex items-center justify-between gap-2 rounded-xl bg-black/25 px-4 py-2 text-sm">
              <div>
                <div className="font-extrabold">
                  {place(d.place)} {d.username} <span className="text-amber-300">· {d.prize}</span>
                </div>
                <div className="text-xs text-white/50">
                  {d.email || "no email"} · {new Date(d.createdAt).toLocaleString()} · pool {d.poolSize}
                </div>
              </div>
              <button
                onClick={async () => {
                  if (confirm("Undo this winner?")) {
                    await post({ action: "undraw", id: d.id });
                    await reload();
                  }
                }}
                className={btnCls}
              >
                Undo
              </button>
            </div>
          ))}
          {!data.draws.length && <div className="py-8 text-center text-white/50">No draws yet.</div>}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------ SETTINGS ------------------------------ */
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-bold uppercase tracking-wider text-white/55">{label}</span>
      {children}
    </label>
  );
}

function SettingsTab({ data, reload }: { data: Overview; reload: () => Promise<void> }) {
  const s = data.settings;
  const [f, setF] = useState(() => ({
    brandName: s.brandName,
    headline: s.headline,
    subheadline: s.subheadline,
    prizes: s.prizes.join("\n"),
    deadline: toLocalInput(s.deadline),
    lockerUrl: s.lockerUrl,
    tokenHours: s.tokenHours,
    requireEmail: s.requireEmail,
    maxEntriesPerIp: s.maxEntriesPerIp,
    notifyEnabled: s.notifyEnabled,
    notifySeconds: s.notifySeconds,
    baseCount: s.baseCount,
    tiktok: s.socials.tiktok,
    youtube: s.socials.youtube,
    offers: s.offers.map((o) => ({ ...o, steps: o.steps.join("\n") })),
    newPassword: "",
  }));
  const [msg, setMsg] = useState("");
  const set = <K extends keyof typeof f>(k: K, v: (typeof f)[K]) => setF((p) => ({ ...p, [k]: v }));
  const setOffer = (i: number, k: "name" | "badge" | "time" | "steps", v: string) =>
    setF((p) => ({ ...p, offers: p.offers.map((o, j) => (j === i ? { ...o, [k]: v } : o)) }));

  async function save(e: React.FormEvent) {
    e.preventDefault();
    const prizes = f.prizes.split("\n").map((x) => x.trim()).filter(Boolean);
    const d = await post({
      action: "settings",
      newPassword: f.newPassword,
      settings: {
        brandName: f.brandName,
        headline: f.headline,
        subheadline: f.subheadline,
        prizes,
        winnersCount: prizes.length,
        deadline: f.deadline ? new Date(f.deadline).toISOString() : s.deadline,
        lockerUrl: f.lockerUrl,
        tokenHours: Number(f.tokenHours),
        requireEmail: f.requireEmail,
        maxEntriesPerIp: Number(f.maxEntriesPerIp),
        notifyEnabled: f.notifyEnabled,
        notifySeconds: Number(f.notifySeconds),
        baseCount: Number(f.baseCount),
        socials: { tiktok: f.tiktok, youtube: f.youtube },
        offers: f.offers,
      },
    });
    setMsg(d.ok ? "✅ Saved!" : d.error === "short_password" ? "Password must be at least 5 characters." : "Error while saving.");
    if (d.ok) {
      set("newPassword", "");
      await reload();
    }
    setTimeout(() => setMsg(""), 4000);
  }

  return (
    <form onSubmit={save} className="space-y-5">
      <div className="glass space-y-4 p-5">
        <h2 className="text-lg font-black">Landing page</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Brand name">
            <input className={inputCls} value={f.brandName} onChange={(e) => set("brandName", e.target.value)} />
          </Field>
          <Field label="Headline">
            <input className={inputCls} value={f.headline} onChange={(e) => set("headline", e.target.value)} />
          </Field>
        </div>
        <Field label="Sub-headline">
          <input className={inputCls} value={f.subheadline} onChange={(e) => set("subheadline", e.target.value)} />
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Prizes (one per line = 1st, 2nd, 3rd…)">
            <textarea className={inputCls} rows={4} value={f.prizes} onChange={(e) => set("prizes", e.target.value)} />
          </Field>
          <div className="space-y-4">
            <Field label="Giveaway ends (your local time)">
              <input type="datetime-local" className={inputCls} value={f.deadline} onChange={(e) => set("deadline", e.target.value)} />
            </Field>
            <Field label="“People entered” starting number (real entries are added on top)">
              <input type="number" min={0} className={inputCls} value={f.baseCount} onChange={(e) => set("baseCount", Number(e.target.value))} />
            </Field>
          </div>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="TikTok link">
            <input className={inputCls} value={f.tiktok} onChange={(e) => set("tiktok", e.target.value)} placeholder="https://tiktok.com/@you" />
          </Field>
          <Field label="YouTube link">
            <input className={inputCls} value={f.youtube} onChange={(e) => set("youtube", e.target.value)} placeholder="https://youtube.com/@you" />
          </Field>
        </div>
      </div>

      {f.offers.map((o, i) => (
        <div key={i} className="glass space-y-4 p-5">
          <h2 className="text-lg font-black">Offer {i + 1}</h2>
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="Name">
              <input className={inputCls} value={o.name} onChange={(e) => setOffer(i, "name", e.target.value)} />
            </Field>
            <Field label="Badge">
              <input className={inputCls} value={o.badge} onChange={(e) => setOffer(i, "badge", e.target.value)} />
            </Field>
            <Field label="Time">
              <input className={inputCls} value={o.time} onChange={(e) => setOffer(i, "time", e.target.value)} />
            </Field>
          </div>
          <Field label="Steps (one per line)">
            <textarea className={inputCls} rows={5} value={o.steps} onChange={(e) => setOffer(i, "steps", e.target.value)} />
          </Field>
        </div>
      ))}

      <div className="glass space-y-4 p-5">
        <h2 className="text-lg font-black">Locker & security</h2>
        <Field label="Content locker URL (the link opened by the big button)">
          <input className={inputCls} value={f.lockerUrl} onChange={(e) => set("lockerUrl", e.target.value)} />
        </Field>
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Pass valid for (hours)">
            <input type="number" min={1} className={inputCls} value={f.tokenHours} onChange={(e) => set("tokenHours", Number(e.target.value))} />
          </Field>
          <Field label="Max entries per IP">
            <input type="number" min={1} className={inputCls} value={f.maxEntriesPerIp} onChange={(e) => set("maxEntriesPerIp", Number(e.target.value))} />
          </Field>
          <Field label="Notification every N seconds">
            <input type="number" min={1} max={60} className={inputCls} value={f.notifySeconds} onChange={(e) => set("notifySeconds", Number(e.target.value))} />
          </Field>
        </div>
        <div className="flex flex-wrap gap-6">
          <label className="flex items-center gap-2">
            <input type="checkbox" className="h-4 w-4 accent-green-400" checked={f.notifyEnabled} onChange={(e) => set("notifyEnabled", e.target.checked)} /> Show activity notifications
          </label>
          <label className="flex items-center gap-2">
            <input type="checkbox" className="h-4 w-4 accent-green-400" checked={f.requireEmail} onChange={(e) => set("requireEmail", e.target.checked)} /> Email required
          </label>
        </div>
        <Field label="New admin password (leave empty to keep the current one)">
          <input type="password" className={inputCls} value={f.newPassword} onChange={(e) => set("newPassword", e.target.value)} placeholder="min 5 characters" />
        </Field>
      </div>

      <div className="sticky bottom-3 flex items-center gap-3">
        <button className="rounded-xl bg-green-400 px-8 py-3 text-lg font-black text-green-950 shadow-xl hover:bg-green-300">Save settings</button>
        {msg && <span className="rounded-lg bg-black/60 px-3 py-2 font-bold">{msg}</span>}
      </div>
    </form>
  );
}

/* ------------------------------ LINKS ------------------------------ */
function LinksTab({ data }: { data: Overview }) {
  const [origin, setOrigin] = useState("");
  const [copied, setCopied] = useState("");
  useEffect(() => setOrigin(window.location.origin), []);
  const rows = [
    ["Landing page — share this on TikTok / YouTube", origin + "/"],
    ["Redirect URL — put this in your content locker as the “after completion” link", origin + "/claim"],
    ["Admin panel (keep private)", origin + "/admin"],
  ];
  return (
    <div className="glass space-y-4 p-5">
      {rows.map(([l, u]) => (
        <div key={l} className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-black/25 p-4">
          <div className="min-w-0">
            <div className="text-xs font-bold uppercase tracking-wider text-white/55">{l}</div>
            <code className="break-all text-green-300">{u}</code>
          </div>
          <button
            className={btnCls}
            onClick={() => {
              navigator.clipboard?.writeText(u);
              setCopied(u);
              setTimeout(() => setCopied(""), 1500);
            }}
          >
            {copied === u ? "Copied ✓" : "Copy"}
          </button>
        </div>
      ))}
      <p className="text-sm text-white/65">
        The button on your landing page opens <b className="text-white">{data.settings.lockerUrl || "(no locker URL set)"}</b> in the same tab. When a visitor
        finishes the offers, your locker must redirect them to the <b className="text-white">/claim</b> link above. The claim page only opens for visitors who
        pressed the big button (a one-time pass). Use ✓ in the Entries tab to mark an entry as verified.
      </p>
    </div>
  );
}
