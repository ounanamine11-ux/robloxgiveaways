import { eq } from "drizzle-orm";
import { db } from "@/db";
import { passes } from "@/db/schema";

export async function findPass(token: string, hours: number) {
  if (!token || token.length < 8 || token.length > 64) return null;
  const rows = await db.select().from(passes).where(eq(passes.id, token)).limit(1);
  const p = rows[0];
  if (!p) return null;
  if (p.createdAt.getTime() < Date.now() - hours * 3600_000) return null;
  return p;
}
