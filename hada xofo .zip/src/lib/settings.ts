import { desc, eq, ne, sql } from "drizzle-orm";
import { db } from "@/db";
import { draws, entries, settings as settingsTable } from "@/db/schema";
import { DEFAULT_SETTINGS, type Offer, type PublicData, type Settings } from "./types";

export async function getSettingsRow(): Promise<{ data: Settings; adminPassword: string }> {
  const rows = await db.select().from(settingsTable).where(eq(settingsTable.id, 1)).limit(1);
  if (rows[0]) {
    return {
      data: { ...DEFAULT_SETTINGS, ...(rows[0].data as Partial<Settings>) } as Settings,
      adminPassword: rows[0].adminPassword,
    };
  }
  const data: Settings = {
    ...DEFAULT_SETTINGS,
    deadline: new Date(Date.now() + 3 * 864e5).toISOString(),
  };
  const pw = process.env.ADMIN_PASSWORD || "robux2026";
  await db
    .insert(settingsTable)
    .values({ id: 1, data: data as unknown as Record<string, unknown>, adminPassword: pw })
    .onConflictDoNothing();
  return { data, adminPassword: pw };
}

export async function getSettings(): Promise<Settings> {
  return (await getSettingsRow()).data;
}

const mask = (u: string) => (u.length <= 3 ? u[0] + "**" : u.slice(0, 2) + "***" + u.slice(-1));

export async function getPublicData(): Promise<PublicData> {
  const settings = await getSettings();
  const [{ total }] = await db
    .select({ total: sql<number>`count(*)::int` })
    .from(entries)
    .where(ne(entries.status, "rejected"));
  const w = await db
    .select({ username: draws.username, prize: draws.prize })
    .from(draws)
    .orderBy(desc(draws.id))
    .limit(3);
  const r = await db
    .select({ username: entries.username })
    .from(entries)
    .where(ne(entries.status, "rejected"))
    .orderBy(desc(entries.id))
    .limit(12);
  return {
    settings,
    total,
    winners: w.map((x) => ({ username: mask(x.username), prize: x.prize })),
    recent: r.map((x) => mask(x.username)),
  };
}

const str = (v: unknown, fallback: string, max = 500) =>
  typeof v === "string" ? v.trim().slice(0, max) : fallback;
const num = (v: unknown, fallback: number, min: number, max: number) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.max(min, Math.min(max, Math.round(n))) : fallback;
};

function toSteps(v: unknown): string[] {
  const arr = Array.isArray(v) ? v : typeof v === "string" ? v.split("\n") : [];
  return arr
    .map((x) => String(x).trim())
    .filter(Boolean)
    .slice(0, 12);
}

export function sanitizeSettings(input: Record<string, unknown>, cur: Settings): Settings {
  const offersIn = Array.isArray(input.offers) ? (input.offers as Record<string, unknown>[]) : null;
  const offers: Offer[] = offersIn
    ? offersIn.slice(0, 4).map((o, i) => ({
        name: str(o.name, cur.offers[i]?.name ?? "Offer", 60),
        badge: str(o.badge, "", 40),
        time: str(o.time, "", 30),
        steps: toSteps(o.steps),
      }))
    : cur.offers;
  const prizes = Array.isArray(input.prizes)
    ? input.prizes.map((p) => String(p).trim()).filter(Boolean).slice(0, 10)
    : cur.prizes;
  let deadline = cur.deadline;
  if (typeof input.deadline === "string" && !Number.isNaN(Date.parse(input.deadline))) {
    deadline = new Date(input.deadline).toISOString();
  }
  const soc = (input.socials ?? {}) as Record<string, unknown>;
  return {
    brandName: str(input.brandName, cur.brandName, 40),
    headline: str(input.headline, cur.headline, 80),
    subheadline: str(input.subheadline, cur.subheadline, 200),
    prizes: prizes.length ? prizes : cur.prizes,
    winnersCount: num(input.winnersCount, cur.winnersCount, 1, 10),
    lockerUrl: str(input.lockerUrl, cur.lockerUrl, 500),
    tokenHours: num(input.tokenHours, cur.tokenHours, 1, 720),
    requireEmail: typeof input.requireEmail === "boolean" ? input.requireEmail : cur.requireEmail,
    maxEntriesPerIp: num(input.maxEntriesPerIp, cur.maxEntriesPerIp, 1, 100),
    notifyEnabled: typeof input.notifyEnabled === "boolean" ? input.notifyEnabled : cur.notifyEnabled,
    notifySeconds: num(input.notifySeconds, cur.notifySeconds, 1, 60),
    baseCount: num(input.baseCount, cur.baseCount, 0, 1_000_000),
    deadline,
    socials: {
      tiktok: str(soc.tiktok, cur.socials.tiktok, 200),
      youtube: str(soc.youtube, cur.socials.youtube, 200),
    },
    offers,
  };
}
