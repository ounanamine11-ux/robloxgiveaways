export type Offer = {
  name: string;
  badge: string;
  time: string;
  steps: string[];
};

export type Settings = {
  brandName: string;
  headline: string;
  subheadline: string;
  prizes: string[];
  winnersCount: number;
  lockerUrl: string;
  tokenHours: number;
  requireEmail: boolean;
  maxEntriesPerIp: number;
  notifyEnabled: boolean;
  notifySeconds: number;
  baseCount: number;
  deadline: string;
  socials: { tiktok: string; youtube: string };
  offers: Offer[];
};

export const DEFAULT_SETTINGS: Settings = {
  brandName: "ROBUX DROP",
  headline: "FREE ROBUX GIVEAWAY",
  subheadline: "3 winners. Complete 2 quick offers and enter your Roblox username.",
  prizes: ["10,000 Robux", "5,000 Robux", "2,500 Robux"],
  winnersCount: 3,
  lockerUrl: "https://shorturl.at/wGrM2",
  tokenHours: 72,
  requireEmail: false,
  maxEntriesPerIp: 3,
  notifyEnabled: true,
  notifySeconds: 3,
  baseCount: 1240,
  deadline: "",
  socials: { tiktok: "", youtube: "" },
  offers: [
    {
      name: "BESTPLAY",
      badge: "Android only",
      time: "~15 min",
      steps: [
        "Click the link and download and install BESTPLAY from the Google Play Store.",
        "Open the app and register.",
        "In the app, download 3 sponsored apps.",
        "Open each one and play for at least 5 minutes (do it for each app, not 5 minutes total).",
      ],
    },
    {
      name: "Ipsos iSay",
      badge: "All devices",
      time: "~5 min",
      steps: [
        "Click the link and open the Ipsos iSay sign-up page.",
        "Register with your real email and create your account.",
        "Complete your profile (basic info: age, location, etc.).",
        "Verify your mobile number with the code sent by SMS.",
      ],
    },
  ],
};

export type PublicData = {
  settings: Settings;
  total: number;
  winners: { username: string; prize: string }[];
  recent: string[];
};
