import { createHmac, timingSafeEqual } from "crypto";
import type { NextRequest } from "next/server";
import { getSettingsRow } from "./settings";

const SECRET = process.env.SESSION_SECRET || process.env.DATABASE_URL || "dev-secret";

export const ADMIN_COOKIE = "gx_admin";

export function tokenFor(password: string): string {
  return createHmac("sha256", SECRET).update("admin:" + password).digest("hex");
}

function safeEqual(a: string, b: string): boolean {
  const x = Buffer.from(a);
  const y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
}

export async function checkPassword(pw: string): Promise<boolean> {
  const { adminPassword } = await getSettingsRow();
  return safeEqual(tokenFor(pw), tokenFor(adminPassword));
}

export async function isAdmin(req: NextRequest): Promise<boolean> {
  const c = req.cookies.get(ADMIN_COOKIE)?.value;
  if (!c) return false;
  const { adminPassword } = await getSettingsRow();
  return safeEqual(c, tokenFor(adminPassword));
}

export function clientIp(req: NextRequest): string | null {
  const xf = req.headers.get("x-forwarded-for");
  const ip = xf ? xf.split(",")[0].trim() : req.headers.get("x-real-ip");
  return ip || null;
}
