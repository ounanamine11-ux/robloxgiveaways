"use client";

import { useEffect, useState } from "react";

type Check =
  | { ok: true; token: string; requireEmail: boolean; deadline: string; socials: { tiktok: string; youtube: string } }
  | { ok: false; reason: "no_pass" | "used"; entry?: { number: number; username: string } | null };

const ERRORS: Record<string, string> = {
  username: "Enter a valid Roblox username (3–20 letters, numbers or underscore).",
  email: "Please enter a valid email address.",
  confirm: "Please confirm that you completed both offers.",
  duplicate: "This username is already entered.",
  iplimit: "Too many entries from your network.",
  used: "This pass was already used.",
  no_pass: "Your pass expired. Please start again from the giveaway page.",
};

export default function ClaimPage() {
  const [state, setState] = useState<"loading" | "form" | "nopass" | "used" | "done">("loading");
  const [info, setInfo] = useState<Check | null>(null);
  const [token, setToken] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [platform, setPlatform] = useState("tiktok");
  const [confirmed, setConfirmed] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [entry, setEntry] = useState<{ number: number; username: string } | null>(null);

  useEffect(() => {
    const q = new URLSearchParams(window.location.search);
    const t = q.get("t") || q.get("subid") || "";
    setToken(t);
    fetch("/api/claim/check" + (t ? `?t=${encodeURIComponent(t)}` : ""))
      .then((r) => r.json())
      .then((d: Check) => {
        setInfo(d);
        if (d.ok) setState("form");
        else if (d.reason === "used") {
          setEntry(d.entry ?? null);
          setState("used");
        } else setState("nopass");
      })
      .catch(() => setState("nopass"));
  }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const r = await fetch("/api/enter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, username, email, platform, confirmed }),
      });
      const d = await r.json();
      if (!r.ok || !d.ok) {
        setError(ERRORS[d.error] ?? "Something went wrong. Try again.");
        if (d.error === "used") setState("used");
        if (d.error === "no_pass") setState("nopass");
      } else {
        setEntry(d.entry);
        setState("done");
      }
    } catch {
      setError("Connection problem. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  const socials = info && info.ok ? info.socials : null;

  return (
    <main className="mx-auto flex min-h-screen max-w-xl items-center px-4 py-10">
      <div className="glass w-full p-6 sm:p-9">
        <a href="/" className="mb-5 inline-block text-sm font-bold text-white/60 hover:text-white">
          ← Back to giveaway
        </a>

        {state === "loading" && <p className="py-10 text-center text-lg text-white/70">Checking your pass…</p>}

        {state === "nopass" && (
          <div className="py-4 text-center">
            <div className="text-6xl">🔒</div>
            <h1 className="mt-3 text-3xl font-black">Verification required</h1>
            <p className="mt-3 text-lg text-white/75">
              You need to complete the offers first. Go back to the giveaway page, press the big green button and finish
              both offers.
            </p>
            <a
              href="/"
              className="mt-6 inline-block rounded-xl bg-green-400 px-6 py-3 text-lg font-black text-green-950 shadow-lg hover:bg-green-300"
            >
              Go to the giveaway
            </a>
          </div>
        )}

        {state === "used" && (
          <div className="py-4 text-center">
            <div className="text-6xl">✅</div>
            <h1 className="mt-3 text-3xl font-black">You are already entered</h1>
            {entry && (
              <p className="mt-3 text-lg text-white/75">
                Entry <b className="text-amber-300">#{entry.number}</b> — <b>{entry.username}</b>
              </p>
            )}
            <p className="mt-2 text-white/60">Each pass works only once. Good luck!</p>
          </div>
        )}

        {state === "done" && entry && (
          <div className="win-pop py-4 text-center">
            <div className="text-7xl">🎉</div>
            <h1 className="gradient-text mt-3 text-4xl font-black">You&apos;re in!</h1>
            <p className="mt-4 text-xl">
              Entry <b className="text-amber-300">#{entry.number}</b>
            </p>
            <p className="mt-1 text-2xl font-black">{entry.username}</p>
            <p className="mt-5 text-lg text-white/75">
              Winners are picked when the countdown ends. Watch our channels to see if you won!
            </p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              {socials?.tiktok && (
                <a href={socials.tiktok} className="rounded-xl bg-white/10 px-5 py-3 font-bold hover:bg-white/20">
                  TikTok
                </a>
              )}
              {socials?.youtube && (
                <a href={socials.youtube} className="rounded-xl bg-white/10 px-5 py-3 font-bold hover:bg-white/20">
                  YouTube
                </a>
              )}
            </div>
          </div>
        )}

        {state === "form" && info && info.ok && (
          <form onSubmit={submit} className="space-y-5">
            <div className="text-center">
              <div className="text-5xl">🎮</div>
              <h1 className="mt-2 text-3xl font-black sm:text-4xl">Last step!</h1>
              <p className="mt-2 text-lg text-white/75">Write your Roblox username to get your entry.</p>
            </div>

            <label className="block">
              <span className="mb-1 block text-sm font-extrabold uppercase tracking-wider text-white/70">Roblox username</span>
              <input
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="e.g. BloxyGamer_23"
                autoComplete="off"
                autoCapitalize="off"
                maxLength={21}
                required
                className="w-full rounded-xl border-2 border-white/15 bg-black/30 px-4 py-4 text-xl font-bold outline-none placeholder:text-white/30 focus:border-green-400"
              />
            </label>

            <label className="block">
              <span className="mb-1 block text-sm font-extrabold uppercase tracking-wider text-white/70">
                Email {info.requireEmail ? "" : "(optional)"}
              </span>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@email.com"
                required={info.requireEmail}
                className="w-full rounded-xl border-2 border-white/15 bg-black/30 px-4 py-3 text-lg outline-none placeholder:text-white/30 focus:border-green-400"
              />
            </label>

            <div>
              <span className="mb-1 block text-sm font-extrabold uppercase tracking-wider text-white/70">
                Where did you find us?
              </span>
              <div className="grid grid-cols-3 gap-2">
                {[
                  ["tiktok", "TikTok"],
                  ["youtube", "YouTube"],
                  ["instagram", "Instagram"],
                ].map(([v, l]) => (
                  <button
                    type="button"
                    key={v}
                    onClick={() => setPlatform(v)}
                    className={`rounded-xl border-2 px-2 py-3 font-bold transition ${
                      platform === v ? "border-green-400 bg-green-400/20" : "border-white/15 bg-black/20 hover:bg-white/10"
                    }`}
                  >
                    {l}
                  </button>
                ))}
              </div>
            </div>

            <label className="flex cursor-pointer items-start gap-3 rounded-xl bg-black/20 p-4">
              <input
                type="checkbox"
                checked={confirmed}
                onChange={(e) => setConfirmed(e.target.checked)}
                className="mt-1 h-5 w-5 accent-green-400"
              />
              <span className="text-base leading-snug">
                I confirm that I really completed <b>both offers</b>. Fake entries are removed.
              </span>
            </label>

            {error && <div className="rounded-xl bg-red-500/20 px-4 py-3 font-bold text-red-200">{error}</div>}

            <button type="submit" disabled={busy} className="cta" style={{ animation: busy ? "none" : undefined }}>
              {busy ? "Sending…" : "Submit my entry"}
              {!busy && <span className="arrow">➜</span>}
            </button>
          </form>
        )}
      </div>
    </main>
  );
}
