import Landing from "@/components/Landing";
import { getPublicData } from "@/lib/settings";

export const dynamic = "force-dynamic";

export default async function Home() {
  const data = await getPublicData();
  return <Landing initial={data} />;
}
