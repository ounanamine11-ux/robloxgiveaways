import { randomUUID } from "crypto";
import { eq, sql } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { passes } from "@/db/schema";
import { clientIp } from "@/lib/auth";
import { findPass } from "@/lib/passes";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

/** Big button pressed: create (or reuse) a pass cookie, return the locker URL. */
export async function POST(req: NextRequest) {
  const s = await getSettings();
  if (!s.lockerUrl) return NextResponse.json({ error: "no_locker" }, { status: 503 });

  const existing = await findPass(req.cookies.get("gx_pass")?.value ?? "", s.tokenHours);
  let id: string;
  if (existing && !existing.used) {
    id = existing.id;
    await db
      .update(passes)
      .set({ clicks: sql`${passes.clicks} + 1` })
      .where(eq(passes.id, id));
  } else {
    id = randomUUID().replace(/-/g, "");
    await db.insert(passes).values({ id, ip: clientIp(req) });
  }

  const res = NextResponse.json({ lockerUrl: s.lockerUrl });
  res.cookies.set("gx_pass", id, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: s.tokenHours * 3600,
  });
  return res;
}
