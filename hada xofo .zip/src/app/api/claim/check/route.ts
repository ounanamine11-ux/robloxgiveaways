import { desc, eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { entries } from "@/db/schema";
import { findPass } from "@/lib/passes";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const s = await getSettings();
  const q = req.nextUrl.searchParams;
  const token = q.get("t") || q.get("subid") || req.cookies.get("gx_pass")?.value || "";
  const pass = await findPass(token, s.tokenHours);
  if (!pass) return NextResponse.json({ ok: false, reason: "no_pass" });
  if (pass.used) {
    const e = await db
      .select()
      .from(entries)
      .where(eq(entries.passId, pass.id))
      .orderBy(desc(entries.id))
      .limit(1);
    return NextResponse.json({
      ok: false,
      reason: "used",
      entry: e[0] ? { number: e[0].number, username: e[0].username } : null,
    });
  }
  return NextResponse.json({
    ok: true,
    token: pass.id,
    requireEmail: s.requireEmail,
    deadline: s.deadline,
    socials: s.socials,
  });
}
