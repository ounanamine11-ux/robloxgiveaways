import { and, eq, ne, sql } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { entries, passes } from "@/db/schema";
import { clientIp } from "@/lib/auth";
import { findPass } from "@/lib/passes";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

const fail = (error: string, status = 400) => NextResponse.json({ error }, { status });
const EMAIL = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const s = await getSettings();
  const token = String(body.token || req.cookies.get("gx_pass")?.value || "");
  const pass = await findPass(token, s.tokenHours);
  if (!pass) return fail("no_pass", 403);
  if (pass.used) return fail("used", 409);

  const username = String(body.username ?? "").trim().replace(/^@+/, "");
  if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) return fail("username");
  const email = String(body.email ?? "").trim();
  if ((s.requireEmail || email) && !EMAIL.test(email)) return fail("email");
  if (body.confirmed !== true) return fail("confirm");
  const platform = ["tiktok", "youtube", "instagram"].includes(String(body.platform))
    ? String(body.platform)
    : "tiktok";

  const dup = await db
    .select({ id: entries.id })
    .from(entries)
    .where(and(sql`lower(${entries.username}) = ${username.toLowerCase()}`, ne(entries.status, "rejected")))
    .limit(1);
  if (dup.length) return fail("duplicate", 409);

  const ip = clientIp(req);
  if (ip) {
    const [{ n }] = await db
      .select({ n: sql<number>`count(*)::int` })
      .from(entries)
      .where(and(eq(entries.ip, ip), ne(entries.status, "rejected")));
    if (n >= s.maxEntriesPerIp) return fail("iplimit", 429);
  }

  // atomically consume the pass (one pass = one entry)
  const claimed = await db
    .update(passes)
    .set({ used: true })
    .where(and(eq(passes.id, pass.id), eq(passes.used, false)))
    .returning({ id: passes.id });
  if (!claimed.length) return fail("used", 409);

  const [{ next }] = await db
    .select({ next: sql<number>`coalesce(max(${entries.number}), 0)::int + 1` })
    .from(entries);
  const [row] = await db
    .insert(entries)
    .values({
      number: next,
      username,
      email: email || null,
      platform,
      passId: pass.id,
      status: "pending",
      ip,
    })
    .returning({ number: entries.number, username: entries.username });

  return NextResponse.json({ ok: true, entry: row });
}
