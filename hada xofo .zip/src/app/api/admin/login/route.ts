import { NextRequest, NextResponse } from "next/server";
import { ADMIN_COOKIE, checkPassword, clientIp, isAdmin, tokenFor } from "@/lib/auth";
import { getSettingsRow } from "@/lib/settings";

export const dynamic = "force-dynamic";

const attempts = new Map<string, { n: number; t: number }>();

export async function GET(req: NextRequest) {
  return NextResponse.json({ ok: await isAdmin(req) });
}

export async function POST(req: NextRequest) {
  const ip = clientIp(req) ?? "unknown";
  const now = Date.now();
  const a = attempts.get(ip);
  if (a && now - a.t < 60_000 && a.n >= 8) {
    return NextResponse.json({ error: "rate" }, { status: 429 });
  }
  const body = (await req.json().catch(() => ({}))) as { password?: string };
  const ok = await checkPassword(String(body.password ?? ""));
  if (!ok) {
    attempts.set(ip, { n: a && now - a.t < 60_000 ? a.n + 1 : 1, t: a && now - a.t < 60_000 ? a.t : now });
    return NextResponse.json({ error: "auth" }, { status: 401 });
  }
  attempts.delete(ip);
  const { adminPassword } = await getSettingsRow();
  const res = NextResponse.json({ ok: true });
  res.cookies.set(ADMIN_COOKIE, tokenFor(adminPassword), {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 7 * 86400,
  });
  return res;
}

export async function DELETE() {
  const res = NextResponse.json({ ok: true });
  res.cookies.set(ADMIN_COOKIE, "", { httpOnly: true, path: "/", maxAge: 0 });
  return res;
}
