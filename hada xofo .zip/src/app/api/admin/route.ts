import { randomUUID } from "crypto";
import { and, desc, eq, ne, sql } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { draws, entries, passes, settings as settingsTable } from "@/db/schema";
import { ADMIN_COOKIE, isAdmin, tokenFor } from "@/lib/auth";
import { getSettingsRow, sanitizeSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

const unauthorized = () => NextResponse.json({ error: "auth" }, { status: 401 });
const bad = (error: string, status = 400) => NextResponse.json({ error }, { status });

export async function GET(req: NextRequest) {
  if (!(await isAdmin(req))) return unauthorized();
  const { data } = await getSettingsRow();

  const [st] = await db
    .select({
      total: sql<number>`count(*)::int`,
      verified: sql<number>`(count(*) filter (where ${entries.status} = 'verified'))::int`,
      pending: sql<number>`(count(*) filter (where ${entries.status} = 'pending'))::int`,
      rejected: sql<number>`(count(*) filter (where ${entries.status} = 'rejected'))::int`,
      today: sql<number>`(count(*) filter (where ${entries.createdAt} >= date_trunc('day', now())))::int`,
      winners: sql<number>`(count(*) filter (where ${entries.won}))::int`,
    })
    .from(entries);
  const [ps] = await db
    .select({
      passes: sql<number>`count(*)::int`,
      clicks: sql<number>`coalesce(sum(${passes.clicks}), 0)::int`,
    })
    .from(passes);

  const list = await db.select().from(entries).orderBy(desc(entries.id)).limit(2000);
  const dr = await db.select().from(draws).orderBy(desc(draws.id)).limit(300);

  return NextResponse.json({
    settings: data,
    stats: { ...st, ...ps },
    entries: list.map((e) => ({ ...e, createdAt: e.createdAt.getTime() })),
    draws: dr.map((d) => ({ ...d, createdAt: d.createdAt.getTime() })),
  });
}

export async function POST(req: NextRequest) {
  if (!(await isAdmin(req))) return unauthorized();
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const action = String(body.action ?? "");

  if (action === "status") {
    const status = String(body.status);
    if (!["verified", "pending", "rejected"].includes(status)) return bad("status");
    const r = await db
      .update(entries)
      .set({ status })
      .where(eq(entries.id, Number(body.id)))
      .returning({ id: entries.id });
    return r.length ? NextResponse.json({ ok: true }) : bad("entry", 404);
  }

  if (action === "delete") {
    const r = await db.delete(entries).where(eq(entries.id, Number(body.id))).returning({ id: entries.id });
    return r.length ? NextResponse.json({ ok: true }) : bad("entry", 404);
  }

  if (action === "clear") {
    if (body.what === "rejected") {
      await db.delete(entries).where(eq(entries.status, "rejected"));
    } else if (body.what === "all") {
      await db.delete(draws);
      await db.delete(entries);
      await db.delete(passes);
    } else return bad("what");
    return NextResponse.json({ ok: true });
  }

  if (action === "draw") {
    const { data } = await getSettingsRow();
    const count = Math.max(1, Math.min(10, Number(body.count) || data.winnersCount));
    const onlyVerified = body.onlyVerified === true;
    const excludeWinners = body.excludeWinners !== false;
    const conds = [ne(entries.status, "rejected")];
    if (onlyVerified) conds.push(eq(entries.status, "verified"));
    if (excludeWinners) conds.push(eq(entries.won, false));

    const pool = await db
      .select({ id: entries.id, username: entries.username, email: entries.email })
      .from(entries)
      .where(and(...conds))
      .orderBy(sql`random()`);
    if (!pool.length) return bad("empty");

    const batch = randomUUID().replace(/-/g, "").slice(0, 8);
    const picked = pool.slice(0, Math.min(count, pool.length));
    const winners = [];
    for (let i = 0; i < picked.length; i++) {
      const w = picked[i];
      const prize = data.prizes[i] ?? "Winner";
      await db.update(entries).set({ won: true, prize }).where(eq(entries.id, w.id));
      const [d] = await db
        .insert(draws)
        .values({
          batch,
          place: i + 1,
          entryId: w.id,
          username: w.username,
          email: w.email,
          prize,
          poolSize: pool.length,
        })
        .returning();
      winners.push({ ...d, createdAt: d.createdAt.getTime() });
    }
    return NextResponse.json({
      batch,
      winners,
      reel: pool.slice(0, 80).map((p) => p.username),
    });
  }

  if (action === "undraw") {
    const id = Number(body.id);
    const d = await db.select().from(draws).where(eq(draws.id, id)).limit(1);
    if (!d[0]) return bad("draw", 404);
    await db.delete(draws).where(eq(draws.id, id));
    const still = await db.select({ id: draws.id }).from(draws).where(eq(draws.entryId, d[0].entryId)).limit(1);
    if (!still.length) await db.update(entries).set({ won: false, prize: "" }).where(eq(entries.id, d[0].entryId));
    return NextResponse.json({ ok: true });
  }

  if (action === "settings") {
    const cur = await getSettingsRow();
    const next = sanitizeSettings((body.settings ?? {}) as Record<string, unknown>, cur.data);
    const newPassword = typeof body.newPassword === "string" ? body.newPassword : "";
    if (newPassword && newPassword.length < 5) return bad("short_password");
    await db
      .update(settingsTable)
      .set({
        data: next as unknown as Record<string, unknown>,
        ...(newPassword ? { adminPassword: newPassword } : {}),
      })
      .where(eq(settingsTable.id, 1));
    const res = NextResponse.json({ ok: true, settings: next });
    if (newPassword) {
      res.cookies.set(ADMIN_COOKIE, tokenFor(newPassword), {
        httpOnly: true,
        sameSite: "lax",
        path: "/",
        maxAge: 7 * 86400,
      });
    }
    return res;
  }

  return bad("action");
}
