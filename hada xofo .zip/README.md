# ROBUX DROP — Giveaway landing + content-locker redirect + admin

## Les liens
| Link | Chno hiya |
|------|-----------|
| `/` | Landing page — hadi li katpartagi f TikTok / YouTube |
| `/claim` | **Redirect URL** — hetha f locker dyalek (fin ykemlo offers w ytsiftou) — fiha ykteb username |
| `/admin` | Panel dyalek (password par défaut: `robux2026` — beddlo mn Settings) |

## Kifach kaykhdem
1. Visitor kayjih mn TikTok/YouTube l `/` → kayqra les 2 offers (BESTPLAY + Ipsos iSay).
2. Kaydghet 3la l'button lkbir → kaytsejjel "pass" f browser dyalo w kayft7 locker (`https://shorturl.at/wGrM2`) f nefs l'onglet.
3. Mnin ykemmel les offers, locker khass yredirigih l `https://DOMAIN/claim`.
4. F `/claim` kayketb Roblox username → kaytsejjel f database. Kol pass kaykhdem merra we7da.
5. F `/admin` katl9a ga3 les participants (recherche, CSV, ✓ verify, ✗ reject) w tab **Draw winners** kat3ti 3 winners b animation.

## Settings li t9der tbeddel (f /admin → Settings)
Headline, prizes, countdown, offers (smiya + steps), locker URL, notifications, email obligatoire wla la, max entries/IP, password.

## Env vars (optionnel)
- `ADMIN_PASSWORD` — password lwl (ghir f awel démarrage, mn b3d beddlo mn panel)
- `SESSION_SECRET` — secret dyal cookie admin

## Remarque
Notifications f landing: "X just entered the giveaway" (kat3tamed 3la usernames réels w random). Ma kaydirch "won" bach tbqa honest.
